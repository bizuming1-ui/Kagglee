# 当前完整源码候选：从可核验S5接线，非正式18发布
默认ICL/6dB上限仍为继承值；不预填用户文本或声音，不拼参考PCM。
分析/校准/S4 worker/S5播放器实际接线；DSP使用numpy-causal-v1，Rust不启用。
真实训练、双T4模型、音质、DeepSeek、实体首声/RTF均未签；建档不等于训练。
S6–S8-C文件当前缺失，未冒称恢复；详见README.zh-CN.md。
